import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';// I'll assume getVehicleDetailsByType is added to VehicleService and returns an Observable<any>
import { GetStatusService, ReceiptStatusResponse } from '../../../core/services/get-status.service';
import { MapboxService } from '../../../core/services/mapbox.service';
import { VehicleService } from '../../../core/services/vehicle.service';
import { ToastComponent } from '../../assets/inactive-assets/toast.component';
import { Subscription } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-report-generation-status',
  standalone: true,
  imports: [FormsModule, CommonModule, ToastComponent],
  templateUrl: './report-generation-status.component.html',
  styleUrl: './report-generation-status.component.scss'
})
export class ReportGenerationStatusComponent implements OnInit, OnDestroy {
  searchBy: string = "";
  responseData: ReceiptStatusResponse = new ReceiptStatusResponse();
  
  isDataLoaded: boolean = false;
  errorMessage: string | null = null;

  // New properties for the vehicle list table
  vehicleDetails: any[] = [];
  isVehicleListLoaded: boolean = false;
  sortKey: string = '';
  reverse: boolean = false;
  task: any | null = sessionStorage.getItem('roleid'); // For conditional columns in the template, assuming it's a number.
  private noTrackDataSubscription: Subscription | undefined;
  currentPage = 1;
  pageSize = 20;
  pageSizeOptions = [20, 50, 100, 200, 500];
  totalCount = 0;
  pageCount = 0;
  detailsflag: boolean = false;
  receiptstatusflag: boolean = false;   
  searchText: string = '';

  constructor(
    private getStatusService: GetStatusService,
    public mapBoxService: MapboxService,
    private vehicleService: VehicleService
  ) {
    this.isDataLoaded = false;
  }

  ngOnInit(): void {
    // Subscribe to the event from MapboxService to know when to close the modal.
    this.noTrackDataSubscription = this.mapBoxService.noTrackData$.subscribe((message) => {
      $('#staticBackdrop').modal('hide');
      if (message) {
        this.errorMessage = message;
      }
    });
    this.getStatusOnInitDetails(1);
  }

  ngOnDestroy(): void {
    // Unsubscribe to prevent memory leaks.
    this.noTrackDataSubscription?.unsubscribe();
  }

  getStatusOnInitDetails(pageNumber: number) {
    this.isVehicleListLoaded = false;
    const requestBody = {
      param1: this.searchBy,
      param2: "New System Data",
      param3: String(pageNumber),
      param4: String(this.pageSize),
      param5: "",
      param6: ""
    };

    // Assuming VehicleService has a method like 'getVehicleDetailsByType' for 'psv_get_vehicledetailsbytype' API
    this.vehicleService.getVehicleDetailsByType(requestBody).subscribe({
      next: (response: any) => {
        if (response && response.status && response.entity && Array.isArray(response.entity.listData)) {
          this.vehicleDetails = response.entity.listData;
          this.isVehicleListLoaded = true;
          this.totalCount = response.entity.param1 || 0;
          this.pageCount = this.vehicleDetails.length;
          this.detailsflag = true;
          this.receiptstatusflag = false; // Set receiptstatusflag
        } else {
          this.errorMessage = 'Failed to load vehicle details or data is not in the expected format.';
          console.warn('Unexpected response structure:', response);
          this.vehicleDetails = [];
          this.detailsflag = true;
          this.receiptstatusflag = false; 
        }
      },
      error: (error: any) => {
        this.isVehicleListLoaded = false;
        this.errorMessage = 'Error fetching vehicle details.';
        console.error('Error fetching vehicle details:', error);
        this.vehicleDetails = [];
      }
    });
  }

  sort(key: string) {
    if (this.sortKey === key) {
      this.reverse = !this.reverse;
    } else {
      this.sortKey = key;
      this.reverse = false;
    }

    this.vehicleDetails.sort((a, b) => {
      const valA = a[key] ?? '';
      const valB = b[key] ?? '';
      if (valA < valB) return this.reverse ? 1 : -1;
      if (valA > valB) return this.reverse ? -1 : 1;
      return 0;
    });
  }

  getSearchDetails() {
    this.getStatusOnInitDetails(1);
  }

  reloadData() {
    this.searchBy = '';
    this.getStatusOnInitDetails(1);
  }

  onPageChange(page: number) {
    this.currentPage = page;
    this.getStatusOnInitDetails(this.currentPage);
  }

  onPageSizeChange(event: Event) {
    const newSize = (event.target as HTMLSelectElement).value;
    this.pageSize = newSize === 'All' ? this.totalCount : Number(newSize);
    this.currentPage = 1;
    this.getStatusOnInitDetails(this.currentPage);
  }

  getTotalPages(): number {
    return Math.ceil(this.totalCount / this.pageSize);
  }

  getPageNumbers(): number[] {
    const totalPages = this.getTotalPages();
    const currentPage = this.currentPage;
    const maxPagesToShow = 7; // Show 7 page numbers at a time

    if (totalPages <= maxPagesToShow) {
      // If total pages are 7 or less, show all page numbers
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const maxPagesBeforeCurrent = Math.floor(maxPagesToShow / 2);
    const maxPagesAfterCurrent = Math.ceil(maxPagesToShow / 2) - 1;
    let startPage: number;
    let endPage: number;

    if (currentPage <= maxPagesBeforeCurrent + 1) {
      startPage = 1;
      endPage = maxPagesToShow;
    } else if (currentPage + maxPagesAfterCurrent >= totalPages) {
      startPage = totalPages - maxPagesToShow + 1;
      endPage = totalPages;
    } else {
      startPage = currentPage - maxPagesBeforeCurrent;
      endPage = currentPage + maxPagesAfterCurrent;
    }
    return Array.from({ length: (endPage - startPage + 1) }, (_, i) => startPage + i);
  }

  getPaginatedData(): any[] {
    return this.vehicleDetails;
  }


  onSearch(item:any) {
    let paramValue = item.param5;
    this.getStatusService.getStatusDetails({ param1: paramValue, param10: '' }).pipe()
      .subscribe({
        next: (response) => {
          if (response.status && response.entity && Object.keys(response.entity).length > 0) {
          this.isDataLoaded = true;
          this.responseData = response.entity;
          this.detailsflag = false;
          this.receiptstatusflag = true; 
          } else {
            this.detailsflag = true;
          this.receiptstatusflag = false; 
            this.isDataLoaded = false;
            this.errorMessage = 'No data found for the given search criteria.';
          }
        },
        error: (error) => {
          this.isDataLoaded = false;
          console.error('Error fetching status details:', error);
        }
      });
  }

  BackToDetails(){
    this.detailsflag = true;
    this.receiptstatusflag = false; 
  }

  openMapModal(serialNo: string) {
    $('#staticBackdrop').modal('show');
    setTimeout(() => {
      this.mapBoxService.initializeMap('mapContainer');
      this.mapBoxService.liveVehicleTrack(serialNo);
    }, 500);
  }

  approveReport() {
    if (!this.responseData || !this.responseData.param12) {
      alert('Cannot approve: Vehicle or Device information is missing.');
      console.error('Vehicle ID (param21) or Device ID (param22) not found in responseData', this.responseData);
      return;
    }

    // Remarks can be captured from a user input if needed.
    const remarks = "ok";

    const request = {
      param1: this.responseData.param12, // vehicleid
      param2: '1', // status
      param3: remarks
    };

    this.vehicleService.updateVehicleActivationStatus(request).subscribe({
      next: (response: any) => {
        if (response.status) {
          let msg = response?.entity;
          this.errorMessage = msg;

          this.onSearch(''); // Refresh the data
        } else {
          let msg = response?.entity || 'An error occurred while approving the report.';
          this.errorMessage = msg;
        }
      },
      error: (err) => {
        let msg = err?.entity;
        this.errorMessage = msg;
      }
    });
  }

  DownloadReport() {
    if (!this.responseData || !this.responseData.param12) {
      this.errorMessage = 'Cannot download report: Vehicle information is missing.';
      console.error('Vehicle ID (param12) not found in responseData', this.responseData);
      return;
    }

    const vehicleId = this.responseData.param12; // As per approveReport, param12 is the vehicleId

    this.getStatusService.getReceiptPdfPath(vehicleId).subscribe({
      next: (response) => {
        if (response.status && response.entity) {
          const filePath = response.entity;
           window.open(filePath, '_blank');
          // The backend returns a server-side absolute path. We assume a web-accessible
          // path can be constructed by finding a known public directory in the path.
          //const psvImagesIndex = filePath.indexOf('/psvimages/');

          // if (psvImagesIndex !== -1) {
          //   const webPath = filePath.substring(psvImagesIndex);
          //   const downloadUrl = window.location.origin + webPath;

          //   const link = document.createElement('a');
          //   link.href = downloadUrl;
          //   link.setAttribute('download', webPath.split('/').pop() || 'receipt.pdf');
          //   link.setAttribute('target', '_blank');
          //   document.body.appendChild(link);
          //   link.click();
          //   document.body.removeChild(link);
          // } else {
          //   this.errorMessage = 'Could not construct a valid download URL from the path received from the server.';
          //   console.error('File path from server does not contain "/psvimages/":', filePath);
          // }
        } else {
          this.errorMessage = response.message || 'Failed to get PDF download link.';
        }
      },
      error: (err) => {
        this.errorMessage = 'An error occurred while trying to download the report.';
        console.error('Error downloading report:', err);
      }
    });
  }
}
