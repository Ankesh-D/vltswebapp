import { Component, OnInit, ViewChild } from '@angular/core';
import { GetStatusService, ReceiptStatusResponse } from '../../../core/services/get-status.service';
import { MapboxService } from '../../../core/services/mapbox.service';
import { VehicleService } from '../../../core/services/vehicle.service';
import { Router } from '@angular/router';
import { DashboardService } from '../../../core/services/dashboard.service';
import { ToastService } from '../../../core/services/toast.service';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UnderscoreToSpacePipe } from '../../../shared/underscore-to-space.pipe';
import moment from 'moment';
import { LoaderService } from '../../../core/services/loader.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { VahanService } from '../../../core/services/vahan.service';

@Component({
  selector: 'app-renewal-device',
  standalone: true,
  imports: [FormsModule, CommonModule, UnderscoreToSpacePipe, NgSelectModule],
  templateUrl: './renewal-device.component.html',
  styleUrl: './renewal-device.component.scss'
})
export class RenewalDeviceComponent implements OnInit {
  statusDetailsFlag: boolean = false;
  searchBy: string = "";
  responseData: ReceiptStatusResponse = new ReceiptStatusResponse();
  totalChecks: any = 0;
  passedChecks: any = 0;
  showActivation: boolean = false;
  isDataLoaded: boolean = false;
  otp: string = "";
  timerText: string = '02:00';
  otpTimerFlag: boolean= false;
  otpResponseCode: any = "";
  
  updateType: string = "";
  editCustomerName: string = "";
  editCustomerMobile: string = "";
  editDeviceIccid: string = "";
  m2mProviderId: string = "";
  m2mProviderObj: any = null;
  m2mProviderList: any[] =[];
  roleId: any = sessionStorage.getItem('roleid');
  activationCheckData: any;
  activationCheckFlag: boolean = false;
  @ViewChild('searchForm') searchForm!: NgForm;
  @ViewChild('editForm') editForm!: NgForm;
  receiveStatus: string='';
  mfgYearList: number[] = [];
  mfgYearObj: any = null;
  networkList: any[]=[];
  vehicleMakeObj: any = null;
  vehicleMakeList: any[] = [];
  vehicleModelObj: any = null;
  vehicleModelList: any[] = [];
  vehicleClassObj: any = null;
  vehicleClassList: any[] = [];
  network1Obj: any =null;
  network1List: any[]=[];
  network2Obj: any =null;
  network2List: any[]=[];
  editMobileNo1: string = "";
  editMobileNo2: string = "";
  rtoList: any[] = [];
  rtoObj: any =null;
  vehicleTypeObj: any= null;
  vehicleTypeList= ['NEW', 'OLD'];
  constructor(
      private getStatusService: GetStatusService,
      public mapBoxService: MapboxService,
      private vehicleService: VehicleService,
      private router: Router,
      private dashboardService: DashboardService,
      public toastService: ToastService,
      public loaderService: LoaderService,
      public vahanService: VahanService
    ) {
      this.isDataLoaded = false;
    }

  ngOnInit(): void {
    this.getM2mProviderList();
    this.loadNetworkList();
    this.loadVehicleMakeList();
    this.loadVehicleClassList();
    this.loadRTOList();
    this.generateYearList();
  }
  generateYearList() {
    const currentYear = new Date().getFullYear();
    for (let i = 2000; i <= currentYear; i++) {
      this.mfgYearList.push(i);
    }
  }
  loadRTOList() {
    this.dashboardService.getRTOList('').subscribe({
      next: (response) => {
        if (response.status && response.entity) {
          this.rtoList = response.entity;
        }
      },
      error: (error) => {
        console.error('Error loading RTO list:', error);
      }
    });
  }
  

  loadVehicleClassList() {
    this.vahanService.getVehicleClassRoster().subscribe({
      next: (response) => {
        if (response?.status && response?.entity) {
          this.vehicleClassList = Array.isArray(response.entity) ? response.entity : [];
        }
      },
      error: (error) => {
        console.error('Error loading vehicle class list:', error);
      }
    });
  }

  loadVehicleMakeList() {
    this.vahanService.getVehicleMakeRoster().subscribe({
      next: (response) => {
        if (response?.status && response?.entity) {
          this.vehicleMakeList = Array.isArray(response.entity) ? response.entity : [];
        }
      },
      error: (error) => {
        console.error('Error loading vehicle make list:', error);
      }
    });
  }
  loadVehicleModelList(makeid:string) {
    this.vahanService.getVehicleModelRosterByMake(makeid).subscribe({
        next: (response) => {
          if (response?.status && response?.entity) {
            this.vehicleModelList = Array.isArray(response.entity) ? response.entity : [];
            this.vehicleModelList.forEach(element => {      
                if(this.responseData.param56 == element.param1) {
                  this.vehicleClassObj = element;
                }
              });
          }
        },
        error: (error) => {
          console.error('Error loading vehicle model list:', error);
        }
      });
  }
  onVehicleMakeChange(make: any) {
    
    if (make) {
      this.vahanService.getVehicleModelRosterByMake(make.param1).subscribe({
        next: (response) => {
          if (response?.status && response?.entity) {
            this.vehicleModelList = Array.isArray(response.entity) ? response.entity : [];
          }
        },
        error: (error) => {
          console.error('Error loading vehicle model list:', error);
        }
      });
    } else {
      this.vehicleModelList = [];
    }
  }
  loadNetworkList() {
    this.dashboardService.getNetworkList().subscribe({
      next: (response) => {
        if (response.status && response.entity) {
          this.networkList = response.entity;
        }
      },
      error: (error) => {
        console.error('Error loading network list:', error);
      }
    });
  }

  getM2mProviderList() {

  this.dashboardService.getM2MProviderList().subscribe({
    next: (response: any) => {

      if (response.status && response.entity) {

        this.m2mProviderList = response.entity;

      } else {

        this.m2mProviderList = [];

      }

    },
    error: () => {

      this.m2mProviderList = [];

    }
  });

}
onM2MProviderChange() {
  this.editDeviceIccid = '';
}
  onFetchClick() {
     if (this.searchForm.valid) {
      let paramValue = this.searchBy.trim();
      this.loaderService.show();
    this.getStatusService.getStatusDetails({ param1: paramValue, param10: 'forrenewal' }).pipe()
      .subscribe({
        next: (response) => {
          this.loaderService.hide();
          if (response.statuscode==200) {
          this.isDataLoaded = true;
          this.responseData = response.entity;
            
          this.statusDetailsFlag = true;
          this.checkDeviceValidity();
          this.vehicleActivationCheck();
          this.getLiveEmergencyData();
          } else {
          this.statusDetailsFlag = false; 
            this.isDataLoaded = false;
            this.toastService.show('No data found for the given search criteria.', 'error');
          }
        },
        error: (error) => {
          this.isDataLoaded = false;
         
        }
      });
     }
  }


  onRefreshClick() {
    if(this.searchForm.valid) {
      this.onFetchClick();
    } else {
      this.toastService.show('Please enter a valid search criteria to refresh.', 'error');
    }
  }

  onClearClick() {
    this.statusDetailsFlag = false;
    this.isDataLoaded = false;
    this.searchForm.resetForm();
    this.responseData = new ReceiptStatusResponse();
  }

  BackToDetails() {}

   checkDeviceValidity() {
    const request = {
      param1: this.responseData.param2 || '', //vendorid
      param4: this.responseData.param1, // deviceid
      param5: this.responseData.param6, // iccidno
      param6: this.responseData.param19, // vehicletype
      param7: this.responseData.param16, //activationdata
      param8: this.responseData.param12 || '' //vehicleid
    };
this.vehicleService.checkDeviceValidity(request).subscribe({
    next: (response) => {

      this.toastService.loaderFlag = false;
      if (response.status && response.entity) {
        if (response.entity.includes('true')) {
          this.receiveStatus = 'true';
          this.toastService.show('Device Valid', 'success');
        } else {
          this.receiveStatus = 'false';
          this.toastService.show('Device not valid for activation', 'error');
        }
      }

    },
    error: () => {
      this.toastService.loaderFlag = false;
      this.toastService.show('Error checking device validity', 'error');
    }
  });
    
    
    this.toastService.loaderFlag = false;
    if (this.responseData.param25 === 'Connected') {
      this.receiveStatus = 'true';
    }
  }
  liveData: any[] = [];
  lastAlertTime: string = '';
  getLiveEmergencyData() {

    this.toastService.loaderFlag = true;
    this.liveData = [];
    this.lastAlertTime = '';


    this.dashboardService.getLiveEmergencyDetails('', '1', '10', this.responseData.param4)
      .subscribe({
        next: (res: any) => {

          this.toastService.loaderFlag = false;

          if (res.status && res.entity) {
            const data = res.entity.listData || [];
            this.liveData = data;
            if (data.length > 0) {
              this.lastAlertTime = data[0].alertdate;
            } else {
              this.lastAlertTime = '';
            }
          }

        },
        error: () => {
          this.toastService.loaderFlag = false;
          this.liveData = [];
          this.lastAlertTime = '';
        }
      });
  }
  editVehicleNo: string = "";
  editChassisNo: string = "";
  editEngineNo: string = "";
  openEditCustomerInfoModal(type: string) {

  this.editCustomerName = this.responseData.param23;
  this.editCustomerMobile = this.responseData.param24;
  this.editDeviceIccid = this.responseData.param6;
  this.editVehicleNo = this.responseData.param13;
  this.editChassisNo = this.responseData.param14;
  this.editEngineNo = this.responseData.param15;    
  if(this.responseData.param52) {
    this.vehicleMakeObj = null
    this.vehicleMakeList.forEach(element => {      
        if(this.responseData.param52 == element.param1) {
          this.vehicleMakeObj = element;
        }
      });
  }
  if(this.responseData.param56) {
    this.vehicleClassObj = null
    this.vehicleClassList.forEach(element => {      
        if(this.responseData.param56 == element.param1) {
          this.vehicleClassObj = element;
        }
      });
  }
  if(this.responseData.param19) {
    this.vehicleTypeList.forEach(element => {
      if(this.responseData.param19.toUpperCase()==element.toUpperCase()) {
        this.vehicleTypeObj = element
      }
    });
  }
  if(this.responseData.param54) {
    this.vehicleModelObj = null;
    this.loadVehicleModelList(this.responseData.param54)
  }
  if(this.responseData.param58) {
    this.network1Obj = null
    this.networkList.forEach(element => {      
        if(this.responseData.param58 == element.param1) {
          this.network1Obj = element;
        }
      });
  }
  if(this.responseData.param60) {
    this.network2Obj = null
    this.networkList.forEach(element => {      
        if(this.responseData.param60 == element.param1) {
          this.network2Obj = element;
        }
      });
  }

  // default selected m2m provider
  // this.m2mProviderObj = this.responseData.param10 || '';
    if(this.responseData.param42) {
      this.m2mProviderList.forEach(element => {      
        if(this.responseData.param42.toUpperCase() == element.param3.toUpperCase()) {
          this.m2mProviderObj = element;
        }
      });
    }
    if(this.responseData.param62) {
      this.rtoList.forEach(element => {      
        if(this.responseData.param62 == element.param1) {
          this.rtoObj = element;
        }
      });
    }
  this.editMobileNo1 = this.responseData.param66;
  this.editMobileNo1 = this.responseData.param67;
  this.mfgYearObj = this.responseData.param22 && this.responseData.param22 != '0' ? Number(this.responseData.param22) : null;
  this.updateType = type;

  this.toastService.openModal('editCustomerInfoModal');
}
   openComplianceCheckModal() {
    this.toastService.openModal('complianceCheckModal');
    // $("#complianceCheckModal").modal('show');
  }

  updateSimValidity() {

    const deviceData = {
      param1: this.responseData.param6 ? this.responseData.param6 : '',   // device iccid no
      param2: this.responseData.param8 ? this.responseData.param8 : '',  // vendor name
      param3: this.responseData.param9 ? this.responseData.param9 : '',  // mgf code
      param4: this.responseData.param42 ? this.responseData.param42 : ''  // m2m code
    };

    
    this.dashboardService.updateSimValidity(deviceData).subscribe({
      next: (response) => {
        const message = response?.entity;

        if (message === 'Successfully saved' || message === 'Successfully updated') {
          
        this.toastService.show('Sim Validity Updated Successfully', 'success');
          // this.validityFlag = true;
          // this.refreshStatus();
        } else {
          this.toastService.show('Sim validity is not available.', 'error');
        
        }

      },
      error: (error) => {
        // commonutility.hidespinner();
        this.toastService.show(error?.error?.entity || 'Something went wrong', 'error')
      }
    });
  }
  getDeviceMode(): string {

    return (this.responseData.param51 || 'NA').toUpperCase();

  }
  isRecentTime(time: string): boolean {
    if (!time) return false;

    const givenTime = new Date(time);
    const now = new Date();

    return (
      givenTime.getDate() === now.getDate() &&
      givenTime.getMonth() === now.getMonth() &&
      givenTime.getFullYear() === now.getFullYear()
    );
  }
  isGpsValid(): boolean {

    const lat = this.responseData.param33;
    const lng = this.responseData.param34;

    // ❌ NA check
    if (
      !lat || !lng ||
      lat === 'NA' || lng === 'NA'
    ) {
      return false;
    }

    const latitude = Number(lat);
    const longitude = Number(lng);

    // ❌ invalid number
    if (
      isNaN(latitude) ||
      isNaN(longitude)
    ) {
      return false;
    }

    // ❌ 0,0 check
    if (latitude === 0 && longitude === 0) {
      return false;
    }

    return true;
  }

  isSimValidityEligible(): boolean {
  
      const today = moment().startOf('day');
  
      // param50
      const sim1 = this.responseData.param27
        ? moment(this.responseData.param27, 'DD-MMM-YYYY')
        : null;
  
      // param51
      const sim2 = this.responseData.param28
        ? moment(this.responseData.param28, 'DD-MMM-YYYY')
        : null;
  
      if (!sim1 || !sim1.isValid() || !sim2 || !sim2.isValid()) {
        return false;
      }
  
      // today + 1 year
      const minValidDate = moment(today).add(1, 'years');
  
      return sim1.isSameOrAfter(minValidDate) &&
        sim2.isSameOrAfter(minValidDate);
    }
  
  

  vehicleActivationCheck() {
  
    let request = {
      "deviceid": this.responseData.param2,
      "time_synced": moment().format('YYYY-MM-DD HH:mm:ss')
    };
  
    this.toastService.loaderFlag = true;
  
    this.vehicleService.checkComplianceAcknowledgement(request).subscribe({
  
      next: (response) => {
  
        this.toastService.loaderFlag = false;
  
        if (response.entity.param1 === 'Success') {
  
          // ✅ Original API Response
          this.activationCheckData = JSON.parse(response.entity.param2)[0];
  
          // ✅ FORCE ALL FALSE ONLY WHEN POLLING NEVER RECEIVED
          if (this.responseData.param25 == 'Never Connected' ||  this.responseData.param25 == 'Not Connected') {
  
            Object.keys(this.activationCheckData).forEach((key) => {
  
              this.activationCheckData[key] = false;
  
            });
  
          }
  
          // ✅ Count
          this.totalChecks = Object.keys(this.activationCheckData).length;
  
          this.passedChecks = Object.values(this.activationCheckData)
            .filter(value => value === 'true' || value === true).length;
          // ✅ Final Flag
          if (this.passedChecks === this.totalChecks) {
  
            this.activationCheckFlag = true;
  
          } else {
  
            this.activationCheckFlag = false;
  
            this.toastService.show('The device has failed to meet AIS-140 compliance requirements. Necessary corrective action must be taken to ensure full compliance before resubmission.',
              'error');
  
          }
  
        }
  
      },
  
      error: (error) => {
  
        this.activationCheckFlag = false;
  
        this.toastService.loaderFlag = false;
  
        // this.msgType = "error";
        this.toastService.show('Error checking compliance acknowledgement', 'error')
        // this.errorMessage = 'Error checking compliance acknowledgement';
  
      }
    });
  
  }
   refreshComplianceCheck() {
    this.vehicleActivationCheck();
  }

  validateForSendOTP(): boolean {
      if(this.responseData.param22 == '0' || this.responseData.param22 == '') {
        this.toastService.show("Manufacturing year is not valid. Please update the manufacturing year to proceed.", 'error');
        return false;
      }

      if(this.responseData.param43 == '') {
        this.toastService.show("Esim Provider is not available. Please update the Esim provider to proceed.", 'error');
        return false;
      }

      if(this.responseData.param25 != "Connected") {
        this.toastService.show('All compliance should be met to send OTP', 'error');
        // this.toastService.show('OTP can only be sent when device is connected', 'error');
        
        return false;
      } else
      if(this.getDeviceMode() != 'TCP') {
        this.toastService.show('All compliance should be met to send OTP', 'error');
        // this.toastService.show('OTP can only be sent when device mode is TCP', 'error');
        
        return false;
      } else
      if(!this.isRecentTime(this.responseData.param32)) {
        
        this.toastService.show('All compliance should be met to send OTP', 'error');
        // this.toastService.show('OTP can only be sent when there is a recent alert (same day)', 'error');
        return false;
      } else
      if(!this.isGpsValid()) {
        
        this.toastService.show('All compliance should be met to send OTP', 'error');
        // this.toastService.show('OTP cannot be sent because GPS data is invalid', 'error');
        return false;
      } else
      if(!this.isSimValidityEligible()) {
        this.toastService.show('All compliance should be met to send OTP', 'error');
        
        // this.toastService.show('OTP cannot be sent because SIM validity is not eligible', 'error');
        return false;
      } else
      if (!this.activationCheckFlag) {
        this.toastService.show('All compliance should be met to send OTP', 'error');
        
        // this.toastService.show('OTP cannot be sent because activation checks have not passed', 'error');
        return false;
      } else if (this.responseData.param51.toLowerCase() !== 'tcp') {
        
        this.toastService.show('All compliance should be met to send OTP', 'error');
        // this.toastService.show('OTP can only be sent when device mode is TCP', 'error');
        return false;
      }
       else {
        
        // this.toastService.show('All conditions met. You can send the OTP.', 'success');
        this.sendOTP();
        return true;
      }
  }

  @ViewChild('otpForm') otpForm!: NgForm;
  sendOTP() {
    const request = {
      param1: this.responseData.param1, //this.deviceId,
      param3: this.responseData.param24, //this.mobileNo,
      param4: this.responseData.param12, //this.deviceDetails.param19 || '',
      param6: this.responseData.param24, //this.deviceDetails.param17 || '',
      param10: this.responseData.param14, //this.chassisNo,
      param11: this.responseData.param4 //this.imeiNo
    };
    this.vehicleService.sendActivationOtp(request).subscribe({
      next: (response) => {
        if (response.statuscode==200) {
          this.otpResponseCode = response.statuscode;
          this.toastService.show('OTP sent successfully', 'success');
          this.showActivation = true;
          this.otpTimerFlag = false
          this.start2MinCounter();
          setTimeout(() => {
            this.otp = "";
            this.otpForm.resetForm();
           
          }, 3000);
        }
      },
      error: (error) => {
        this.toastService.show('Error sending OTP', 'error');
      }
    }); 
  }
 
private intervalRef: any;

start2MinCounter() {
  let totalSeconds = 2 * 60; // 2 minutes
  this.otpTimerFlag = true;
  // clear old timer if running
  if (this.intervalRef) clearInterval(this.intervalRef);

  this.intervalRef = setInterval(() => {
    const min = Math.floor(totalSeconds / 60);
    const sec = totalSeconds % 60;

    this.timerText = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

    totalSeconds--;

    if (totalSeconds < 0) {
      this.otpTimerFlag = false;
      clearInterval(this.intervalRef);
      this.timerText = '00:00';
      //r finished');
    }
  }, 1000);
}
  
  activateVehicle() {
    if (!this.otp || this.otp.length !== 6) {
      this.toastService.show('Please enter valid OTP', 'error');
      return;
    }
    
    
    
    const request = {
      "param1": this.responseData.param1 ? this.responseData.param1 : '',//deviceid,
      "param2": this.otp,//otp,
      "param3": this.responseData.param24 ? this.responseData.param24 : '',//mobileno,
      "param4": this.responseData.param12 || '',//vehicleid
      "param6": 'renewal'
    };

    
    this.vehicleService.activateVehicle(request).subscribe({
      next: (response) => {
        if (response.status && response.entity) {

          if (response.entity.includes('Successfully')) {
            this.toastService.show(response.entity, 'success');
            setTimeout(() => {
              this.router.navigate(['/getstatus']);
              this.otpResponseCode = null;
            }, 3000);
          } else {
            this.toastService.show(response.entity, 'error');
          }
        }
      },
      error: (error) => {
        this.toastService.show('Error activating vehicle', 'error');
      }
    });
  }
  saveCustomerInfo() {
  if(this.editForm.invalid) {
    this.toastService.show('All fields are mendatory.');
    return false;
  }

  const request = {
  vehicleid: this.responseData.param12 || '',
  customername: this.editCustomerName,
  customermobileno: this.editCustomerMobile,
  iccidno: this.editDeviceIccid,
  m2mproviderid: this.m2mProviderObj ? this.m2mProviderObj.param1 : '',
  mfgyear: this.mfgYearObj ? this.mfgYearObj : '',
  "vehicleno": this.editVehicleNo,
  "chassisno": this.editChassisNo,
  "engineno": this.editEngineNo,
  "vehiclemakeid": this.vehicleMakeObj ? this.vehicleMakeObj.param1 : "",
  "vehiclemodelid": this.vehicleModelObj ? this.vehicleModelObj.param1 : "",
  "vehicleclassid": this.vehicleClassObj ? this.vehicleClassObj.param1 : "",
  "vehicletype": this.vehicleTypeObj ? this.vehicleTypeObj : "",
  "mobileno1": this.editMobileNo1 ? this.editMobileNo1 : '',
  "networkid1": this.network1Obj ? this.network1Obj.param1 : "",
  "mobileno2": this.editMobileNo2 ? this.editMobileNo2 : "",
  "networkid2": this.editMobileNo1 ? this.editMobileNo1 : '',
  "rtoid": this.rtoObj ? this.rtoObj.param1 : '',
   // Assuming param1 is the ID of the M2M provider
};
console.log(request)
return true;
    this.vehicleService.updateRenewalInfo(request).subscribe({
      next: (response: any) => {
        if (response.status) {
          if(response.statuscode=='200') {
            this.toastService.show('Customer info updated successfully', 'success');
            // $('#editCustomerInfoModal').modal('hide');
            this.toastService.closeModal('editCustomerInfoModal');
            this.onFetchClick();
          } else {
            this.toastService.show('Something went wrong! Please try again', 'error');
          }
        } else {
          this.toastService.show('Failed to update customer info', 'error');
        }
      },
      error: () => {
        this.toastService.show('Error updating customer info', 'error');
      }
    }); 
  }
}
